<?php
/**
 * Salient widget areas and custom widgets
 *
 * @package Salient WordPress Theme
 * @subpackage helpers
 * @version 10.5
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


// Salient widgets have moved to the plugin "Salient widgets".