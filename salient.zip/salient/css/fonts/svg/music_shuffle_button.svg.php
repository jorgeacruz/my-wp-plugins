<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="0,48 15,48 47,16 63,16 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="37,38 47,48 63,48 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="0,16 15,16 25,26 "/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" d="M56,23"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="56,23 63,16 56,9 
	"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="56,55 63,48 
	56,41 "/>
</svg>
