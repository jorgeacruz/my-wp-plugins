<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="30" y1="10" x2="64" y2="10"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="20" x2="53" y2="20"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="30" x2="64" y2="30"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="40" x2="56" y2="40"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="50" x2="64" y2="50"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="60" x2="58" y2="60"/>
<g>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="16,17 23,10 
		16,3 	"/>
	<g>
		<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="23" y1="10" x2="0" y2="10"/>
	</g>
</g>
</svg>
