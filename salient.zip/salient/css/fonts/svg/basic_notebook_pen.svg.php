<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<polygon fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="63,3 63,53 59,61 55,53 55,3 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="55,7 51,7 51,17 "/>
<rect x="4" y="3" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="40" height="58"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="34" y1="3" x2="34" y2="60"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="8" y1="16" x2="0" y2="16"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="8" y1="8" x2="0" y2="8"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="8" y1="24" x2="0" y2="24"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="8" y1="32" x2="0" y2="32"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="8" y1="40" x2="0" y2="40"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="8" y1="48" x2="0" y2="48"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="8" y1="56" x2="0" y2="56"/>
</svg>
