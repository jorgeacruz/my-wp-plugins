<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="18" cy="55" r="8"/>
	<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="46" cy="49" r="8"/>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="54,49 54,1 26,7 26,55 	"/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="26" y1="23" x2="54" y2="17"/>
</g>
</svg>
