<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="36,24 44,1 45,1 53,24 	"/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="38" y1="17" x2="51" y2="17"/>
</g>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="27" y1="28" x2="61" y2="28"/>
<g>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="36,57 44,34 45,34 53,57 	"/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="38" y1="50" x2="51" y2="50"/>
</g>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="27" y1="61" x2="61" y2="61"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="5,55 12,62 19,55 
	"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="19,34 12,27 5,34 
	"/>
<g>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="12" y1="62" x2="12" y2="27"/>
</g>
</svg>
