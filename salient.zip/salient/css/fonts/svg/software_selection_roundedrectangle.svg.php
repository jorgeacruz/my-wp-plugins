<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="3.9436,1.9718" d="M63,40
		c0,6.627-5.373,12-12,12H13C6.373,52,1,46.627,1,40V24c0-6.627,5.373-12,12-12h38c6.627,0,12,5.373,12,12V40z"/>
</g>
</svg>
